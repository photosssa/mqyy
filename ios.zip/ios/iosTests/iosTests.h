//
//  iosTests.h
//  iosTests
//
//  Created by Tsukasa on 12-12-31.
//  Copyright (c) 2012年 Tsukasa. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface iosTests : SenTestCase

@end
